#--------------------------------------------------------#
#### A new framework to understand context dependence ####
#### of two species population dynamics: a case study ####
#### of rocky intertidal sessile assembly             ####
#--------------------------------------------------------#

#--------------------------------------------------------#
#####    Yuan YAO, Keiichi FUKAYA and Takashi NODA    ####
#--------------------------------------------------------#

#--------------------------------------------------------#
####            statistical analysis code             ####
#--------------------------------------------------------#


##observed data
load("abundance_data.rda")

library(ggplot2)
##For Fig.2
ggplot()+
  geom_boxplot(data = abundancedat, aes(x=group, y=value))+
  theme(panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank(),
        panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(),
        axis.title = element_blank())

##analysis
##load posterior medians of all parameters
load("posterior_medians.rda")

#standardization
library(MARSS)
rs_c<-zscore(dat$r1)
rs_g<-zscore(dat$r2)
r_c<-dat$r1
r_g<-dat$r2
a_cc<-dat$a11
a_cg<-dat$a12
a_gc<-dat$a21
a_gg<-dat$a22

dat<-data.frame(rs_c, rs_g,r_c,r_g,a_cc,a_cg,a_gc,a_gg)


##boxplot
library(ggplot2)

#new function for scale y-aix
squash_axis <- function(from, to, factor) { 
  # A transformation function that squashes the range of [from, to] by factor on a given axis 
  
  # Args:
  #   from: left end of the axis
  #   to: right end of the axis
  #   factor: the compression factor of the range [from, to]
  #
  # Returns:
  #   A transformation called "squash_axis", which is capsulated by trans_new() function
  
  trans <- function(x) {    
    # get indices for the relevant regions
    isq <- x > from & x < to
    ito <- x >= to
    
    # apply transformation
    x[isq] <- from + (x[isq] - from)/factor
    x[ito] <- from + (to - from)/factor + (x[ito] - to)
    
    return(x)
  }
  
  inv <- function(x) {
    
    # get indices for the relevant regions
    isq <- x > from & x < from + (to - from)/factor
    ito <- x >= from + (to - from)/factor
    
    # apply transformation
    x[isq] <- from + (x[isq] - from) * factor
    x[ito] <- to + (x[ito] - (from + (to - from)/factor))
    
    return(x)
  }
  
  # return the transformation
  return(scales::trans_new("squash_axis", trans, inv, domain = c(from, to)))
}


##For Fig.3 a
rdat<-data.frame(group=rep(c('r_c', 'r_g'), each = 33), 
                 value=c(r_c,r_g))

ggplot()+
  geom_boxplot(data = rdat, aes(x=group, y=value))+expand_limits(y = 0)+
  coord_trans(y = squash_axis(0, 3.5,6))+ggtitle("")+theme(
    axis.line = element_line(),
    axis.title = element_blank())

##For Fig.3 b
adat<- data.frame(group=rep(c('a', 'b', 'c', 'd'), each = 33), 
                  value=c(a_cc,a_gc,a_gg,a_cg))

ggplot(adat,aes(x=group, y = value))+
  geom_boxplot()+expand_limits(y = 0)+
  coord_trans(y = squash_axis(0.2, 0.6,6))+ggtitle("")+theme(
    axis.line = element_line(),
    axis.title = element_blank())


#glm/gam
library(mgcv)
lm.a_cc.r_c<-lm(a_cc~r_c,data = dat)
lm.a_cg.r_c<-lm(a_cg~r_c,data = dat)
lm.a_gc.r_c<-lm(a_gc~r_c,data = dat)
lm.a_gg.r_c<-lm(a_gg~r_c,data = dat)

lm.a_cc.r_g<-lm(a_cc~r_g,data = dat)
lm.a_cg.r_g<-lm(a_cg~r_g,data = dat)
lm.a_gc.r_g<-lm(a_gc~r_g,data = dat)
lm.a_gg.r_g<-lm(a_gg~r_g,data = dat)

lm.a_cc.p<-lm(a_cc~r_c+r_g,data = dat)
lm.a_cg.p<-lm(a_cg~r_c+r_g,data = dat)
lm.a_gc.p<-lm(a_gc~r_c+r_g,data = dat)
lm.a_gg.p<-lm(a_gg~r_c+r_g,data = dat)

lm.a_ccx<-lm(a_cc~r_c*r_g,data = dat)
lm.a_cgx<-lm(a_cg~r_c*r_g,data = dat)
lm.a_gcx<-lm(a_gc~r_c*r_g,data = dat)
lm.a_ggx<-lm(a_gg~r_c*r_g,data = dat)


gam_a_cc.x<-gam(a_cc~s(r_c,r_g), data = dat)
gam_a_cc.p<-gam(a_cc~s(r_c)+s(r_g), data = dat)
gam_a_cc.r_c<-gam(a_cc~s(r_c), data = dat)
gam_a_cc.r_g<-gam(a_cc~s(r_g), data = dat)
gam_a_cc.r_cl<-gam(a_cc~r_g+s(r_c), data = dat)
gam_a_cc.r_gl<-gam(a_cc~s(r_g)+r_c, data = dat)

gam_a_cg.x<-gam(a_cg~s(r_c,r_g), data = dat)
gam_a_cg.p<-gam(a_cg~s(r_c)+s(r_g), data = dat)
gam_a_cg.r_c<-gam(a_cg~s(r_c), data = dat)
gam_a_cg.r_g<-gam(a_cg~s(r_g), data = dat)
gam_a_cg.r_cl<-gam(a_cg~s(r_c)+r_g, data = dat)
gam_a_cg.r_gl<-gam(a_cg~s(r_g)+r_c, data = dat)

gam_a_gc.x<-gam(a_gc~s(r_g,r_c), data = dat)
gam_a_gc.p<-gam(a_gc~s(r_c)+s(r_g), data = dat)
gam_a_gc.r_c<-gam(a_gc~s(r_c), data = dat)
gam_a_gc.r_g<-gam(a_gc~s(r_g), data = dat)
gam_a_gc.r_cl<-gam(a_gc~s(r_c)+r_g, data = dat)
gam_a_gc.r_gl<-gam(a_gc~s(r_g)+r_c, data = dat)

gam_a_gg.x<-gam(a_gg~s(r_c,r_g), data = dat)
gam_a_gg.p<-gam(a_gg~s(r_g)+s(r_c), data = dat)
gam_a_gg.r_c<-gam(a_gg~s(r_c), data = dat)
gam_a_gg.r_g<-gam(a_gg~s(r_g), data = dat)
gam_a_gg.r_cl<-gam(a_gg~s(r_c)+r_g, data = dat)
gam_a_gg.r_gl<-gam(a_gg~s(r_g)+r_c, data = dat)

#model selection
AIC(lm.a_ccx,lm.a_cc.p,lm.a_cc.r_c,lm.a_cc.r_g,gam_a_cc.x,gam_a_cc.p,gam_a_cc.r_c,gam_a_cc.r_g,gam_a_cc.r_cl,gam_a_cc.r_gl)
AIC(lm.a_cgx,lm.a_cg.p,lm.a_cg.r_c,lm.a_cg.r_g,gam_a_cg.x,gam_a_cg.p,gam_a_cg.r_c,gam_a_cg.r_g,gam_a_cg.r_cl,gam_a_cg.r_gl)
AIC(lm.a_gcx,lm.a_gc.p,lm.a_gc.r_c,lm.a_gc.r_g,gam_a_gc.x,gam_a_gc.p,gam_a_gc.r_c,gam_a_gc.r_g,gam_a_gc.r_cl,gam_a_gc.r_gl)
AIC(lm.a_ggx,lm.a_gg.p,lm.a_gg.r_c,lm.a_gg.r_g,gam_a_gg.x,gam_a_gg.p,gam_a_gg.r_c,gam_a_gg.r_g,gam_a_gg.r_cl,gam_a_gg.r_gl)

#For Fig.4 a
vis.gam(gam_a_cc.p,color = "heat", main="a_cc",plot.type="contour",asp=1,ylim=c(3.58,4.06))
axis(side = 1, at = c(4.5,4.7,4.9,5.1))
points(dat$r_c,dat$r_g)

#For Fig.4 b
vis.gam(gam_a_gg.p,color = "heat", main="a_gg",plot.type="contour",asp=1,ylim=c(4.59,5.07))
axis(1,at=c(3.5,3.7,3.9,4.1))
points(dat$r_g,dat$r_c)

#For Fig.4 c
vis.gam(gam_a_cg.r_gl,color = "heat", main="a_cg",plot.type="contour",asp=1,ylim=c(3.58,4.06))
axis(side = 1, at = c(4.5,4.7,4.9,5.1))
points(dat$r_c,dat$r_g)

#For Fig.4 d
vis.gam(gam_a_gc.x,color = "heat", main="a_gc",plot.type="contour",asp=1,ylim=c(4.59,5.07))
axis(1,at=c(3.5,3.7,3.9,4.1))
points(dat$r_g,dat$r_c)
