#--------------------------------------------------------#
#### A new framework to understand context dependence ####
#### of two species population dynamics: a case study ####
#### of rocky intertidal sessile assembly             ####
#--------------------------------------------------------#

#--------------------------------------------------------#
#####    Yuan YAO, Keiichi FUKAYA and Takashi NODA    ####
#--------------------------------------------------------#

#--------------------------------------------------------#
####                    JAGS code                     ####
#--------------------------------------------------------#

library(rjags)
library(R2jags)
library(rjags)
library(coda)

model.loc <- "ss_model.txt"
jagsscript <- cat("
   model {  
   # priors
   for (j in 1:J){
   a11[j] ~ dnorm(mu_a11,tau_a11)
   a12[j] ~ dnorm(mu_a12,tau_a12)
   a21[j] ~ dnorm(mu_a21,tau_a21)
   a22[j] ~ dnorm(mu_a22,tau_a22)
   r1[j] ~ dnorm(mu_r1,tau_r1)
   r2[j] ~ dnorm(mu_r2,tau_r2)
   }
   
   tau1 <- pow(sd1, -2)
   sd1 ~ dunif(0, 1E2)
   tau2 <- pow(sd2, -2)
   sd2 ~ dunif(0, 1E2)
   tau_a11 <- pow(sd_a11, -2)
   sd_a11 ~ dunif(0, 1E2)   
   tau_a12 <- pow(sd_a12, -2)
   sd_a12 ~ dunif(0, 1E2)   
   tau_a21 <- pow(sd_a21, -2)
   sd_a21 ~ dunif(0, 1E2)
   tau_a22 <- pow(sd_a22, -2)
   sd_a22 ~ dunif(0, 1E2)
   tau_r1 <- pow(sd_r1, -2)
   sd_r1 ~ dunif(0, 1E2)   
   tau_r2 <- pow(sd_r2, -2)
   sd_r2 ~ dunif(0, 1E2)
   mu_a11~dnorm(0,1E-4)
   mu_a12~dnorm(0,1E-4)
   mu_a21~dnorm(0,1E-4)
   mu_a22~dnorm(0,1E-4)
   mu_r1~dnorm(0,1E-4)
   mu_r2~dnorm(0,1E-4)
   
   #data model
   for (t in 1:TT){
   for (j in 1:J){
   Y[t,j,1:3] ~ dmulti(c(exp(N1[t,j]),exp(N2[t,j]),(1000-exp(N1[t,j])-exp(N2[t,j])))/1000, N); 
      }
   }
 
   #Process model
   #For t>1
   for(t in 2:TT) {
   for (j in 1:J){
   proc1[t-1,j]<-r1[j]+(1-a11[j])*N1[t-1,j]-a12[j]*N2[t-1,j]
   proc2[t-1,j]<-r2[j]+(1-a22[j])*N2[t-1,j]-a21[j]*N1[t-1,j]
   N1[t,j] ~ dnorm(proc1[t-1,j],tau1);
   N2[t,j] ~ dnorm(proc2[t-1,j],tau2);
   
   }
   }
   #For t=1
   for (j in 1:J){ 
   N1[1,j]=log(1000) + log(p1)
   N2[1,j]=log(1000) + log(1 - p1) + log(p2)
   }
   
   p1 ~ dbeta(1, 1)
   p2 ~ dbeta(1, 1)
   }                  
   ", 
                  file = model.loc)

load("data_for_JAGS.rda")

jags.data <- list(Y = z2, TT = 18,J=33, N=40)
jags.params <- c("a11", "a12", "a21", "a22", "r1", "r2", "N1", "N2")
mod_ss <- jags(jags.data, parameters.to.save = jags.params, model.file = model.loc, 
               n.chains = 4, n.burnin = 50000, n.thin = 10, n.iter = 100000, 
               DIC = TRUE)

output<-mod_ss$BUGSoutput$summary
